<?php

/**
 * Database credentials — keep this file out of public git remotes.
 * Copy from database.example.php if needed.
 */
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

if ($host === 'localhost' || $host === '127.0.0.1') {
    return [
        // 127.0.0.1 forces TCP on macOS/MAMP (avoids missing unix socket)
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'dbname'   => 'eddymacon',
        'username' => 'root',
        'password' => '1234567890',
        'charset'  => 'utf8mb4',
    ];
}

return [
    'host'     => 'localhost',
    'port'     => 3306,
    'dbname'   => 'scaneenw_eddy_macon',
    'username' => 'scaneenw_eddy_macon',
    'password' => 'Z@BzBpkl5tudet8g',
    'charset'  => 'utf8mb4',
];
